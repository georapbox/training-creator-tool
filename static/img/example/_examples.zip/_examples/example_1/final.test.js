const initial = require("./initial");

it("calls initial with an array and returns a filtered array", () => {
  // GIVEN
  const people = [
    { name: "Sofia", age: 28, id: true },
    { name: "Kostis", age: 35, id: true },
    { name: "Afroditi", age: 22, id: false },
    { name: "George", age: 30, id: false },
    { name: "John", age: 25, id: true },
    { name: "Christine", age: 16, id: true },
  ];
  // WHEN
  const result = initial(people);

  // THEN
  const filteredArr = [
    { name: "Sofia", age: 28, id: true },
    { name: "Kostis", age: 35, id: true },
    { name: "John", age: 25, id: true },
  ];

  expect(result).toEqual(filteredArr);
});
