const greeting = "Hello";

const outerFunc = () => {  
  const innerFunc = () => {
    return greeting;
  };

  innerFunc();
};

outerFunc();