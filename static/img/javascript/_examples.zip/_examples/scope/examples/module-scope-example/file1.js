export const sayHello = () => {
  const greeting = "Hello";
  console.log(greeting);
};

const sayHola = () => {
  const greeting = "Hola";
  console.log(greeting);
};

sayHello();
sayHola();
