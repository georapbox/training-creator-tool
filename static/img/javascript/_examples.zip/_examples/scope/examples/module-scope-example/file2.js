import { sayHello } from "./file1";

sayHello();
sayHola();
