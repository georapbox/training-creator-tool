const sayHello = () => {
  var greeting = "Hello";
  console.log(greeting);
};

console.log(greeting);
