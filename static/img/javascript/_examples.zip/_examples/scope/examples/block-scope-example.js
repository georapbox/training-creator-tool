if (true) {
  const greeting = "Hello";
  console.log(greeting);
}

console.log(greeting);
