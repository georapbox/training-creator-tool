const name = "Sofia";

const outerFunc = () => {
  const greeting = "Hello";

  const innerFunc = () => {
    return console.log(`${greeting} ${name}`);
  };

  innerFunc();
};

outerFunc();