const sayHello = () => {
  console.log(greeting);
};

sayHello();
