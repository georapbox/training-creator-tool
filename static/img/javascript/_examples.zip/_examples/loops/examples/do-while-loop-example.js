let i = 1;

do {
  console.log(`This is loop number ${i}`);
  i++;
} while (i < 4);
