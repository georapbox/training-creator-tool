for (let i = 3; i > 0; i--) {
  console.log(`This is loop number ${i}`);
}