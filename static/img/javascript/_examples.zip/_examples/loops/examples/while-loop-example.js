let i = 1;

while (i < 4) {
  console.log(`This is loop number ${i}`);
i++;