const bestFoods = ["burger", "pizza", "salad", "sushi"];

for (let i = 0; i < bestFoods.length; i++) {
  if (bestFoods[i] === "salad") {
    continue;
  }
  console.log(bestFoods[i]);
}