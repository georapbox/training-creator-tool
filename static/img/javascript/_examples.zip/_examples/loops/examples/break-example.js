for (let i = 0; i < 99; i++) {
  if (i > 2) {
    break;
  }
  console.log("I am imprisoned!");
}

console.log("I broke out of the loop!");

/* output:
  I am imprisoned!
  I am imprisoned!
  I am imprisoned!
  I broke out of the loop!
*/
