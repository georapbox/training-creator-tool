const loopingArrays = ["This", "is", "so", "easy"];

for (let i = 0; i < loopingArrays.length; i++) {
  console.log(loopingArrays[i]);
}
