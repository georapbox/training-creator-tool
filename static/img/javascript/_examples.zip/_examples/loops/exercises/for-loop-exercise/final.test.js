const initial = require("./initial");

it("prints fizzbuzz properly", () => {
  initial();

  expect(console.log.mock.calls[2][0]).toEqual("fizz");
  expect(console.log.mock.calls[3][0]).toEqual(4);
  expect(console.log.mock.calls[4][0]).toEqual("buzz");
  expect(console.log.mock.calls[14][0]).toEqual("fizzbuzz");
});

beforeEach(() => {
  jest.spyOn(console, "log").mockImplementation(() => {});
});

afterEach(() => {
  console.log.mockRestore();
});
