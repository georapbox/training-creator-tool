/* Task:
  A) Write a for loop that iterates the integers from 1 to 20
  and console logs the numbers.

  In the following cases intead of the number, print: 
  - "fizz" for multiples of three
  - "buzz" for multiples of five
  - "fizzbuzz" for multiples of both three and five

  B) Stop the execution inside the loop, when the iteration is greater than 15. 
*/

const initial = () => {
  // TODO: provide implementation
};

module.exports = initial;
