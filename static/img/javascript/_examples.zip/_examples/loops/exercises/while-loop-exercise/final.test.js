const initial = require("./initial");

it("removes all 5 spoons of sugar from the jar", () => {
  // GIVEN
  const sugarJar = 5;

  // WHEN
  const result = initial(sugarJar);

  // THEN
  expect(result).toBe(5);
});
