/* Task:
  A) Write a loop that adds spoons of sugar to my coffee,
  keeps adding until the jar is empty
  and notifies me of the current quantity.

  B) Improve the program to add at least one spoon of sugar.
*/

const initial = (sugarJar) => {
  let spoonsOfSugar = 0;

  // TODO: provide implementation

  return spoonsOfSugar;
};

module.exports = initial;
