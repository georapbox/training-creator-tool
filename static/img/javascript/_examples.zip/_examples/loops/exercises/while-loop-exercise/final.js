const final = (sugarJar) => {
  let spoonsOfSugar = 0;

  do {
    spoonsOfSugar++;
  } while (spoonsOfSugar < sugarJar);

  return spoonsOfSugar;
};

module.exports = final;
