const initial = require("./initial");

describe("compares the items of two lists", () => {
  it("returns a new one with the common items", () => {
    // GIVEN
    const myCards = ["JackOfHearts", "KingOfSpades", "5Clover", "10Heart", "4Diamond"];
    const yourCards = ["QueenOfHearts", "10Heart", "4Diamond", "5Clover"];

    // WHEN
    const result = initial(myCards, yourCards);
    
    // THEN
    expect(result).toEqual(["5Clover", "10Heart", "4Diamond"]);
  });

  it("excludes from the common items the AceSpade", () => {
    // GIVEN
    const myCards = ["JackOfHearts", "KingOfSpades", "5Clover", "10Heart", "AceSpade"];
    const yourCards = ["QueenOfHearts", "10Heart", "AceSpade", "4Diamond", "5Clover"];

    // WHEN
    const result = initial(myCards, yourCards);
    
    // THEN
    expect(result).toEqual(["5Clover", "10Heart"]);
  });
});

