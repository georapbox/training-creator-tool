/* Task:
  A) Write a nested loop that iterates through the following lists of cards,
  compares them one by one,
  extracts the cards which exist in both arrays
  and pushes them into a third array.
  
  HINT: You should use the JavaScript array method .push() which adds an element to an array.

  B) If a card is equal to "AceSpade", skip this iteration. 
*/

const myCards = [
  "JackOfHearts",
  "KingOfSpades",
  "5Clover",
  "10Heart",
  "AceSpade",
];

const yourCards = [
  "QueenOfHearts",
  "10Heart",
  "AceSpade",
  "4Diamond",
  "5Clover",
];

const initial = (myCards, yourCards) => {
  const mutualCards = [];

  // TODO: provide implementation

  return mutualCards;
};

module.exports = initial;
