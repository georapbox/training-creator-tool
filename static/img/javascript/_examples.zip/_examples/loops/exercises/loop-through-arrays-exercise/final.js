const myCards = [
  "JackOfHearts",
  "KingOfSpades",
  "5Clover",
  "10Heart",
  "AceSpade",
];
const yourCards = [
  "QueenOfHearts",
  "10Heart",
  "AceSpade",
  "4Diamond",
  "5Clover",
];

const final = (myCards, yourCards) => {
  const mutualCards = [];
  
  for (let i = 0; i < myCards.length; i++) {
    if (myCards[i] === "AceSpade") {
      continue;
    }
    
    for (let j = 0; j < yourCards.length; j++) {
      if (myCards[i] === yourCards[j]) {
        mutualCards.push(myCards[i]);
      }
    }
  }

  return mutualCards;
};

module.exports = final;
