// examples of logical AND operator
const expr1 = true && true; // output: true
const expr2 = true && false; // output: false
const expr3 = false && true; // output: false
const expr4 = "Dog" && "Cat"; // output: Cat
const expr5 = "" && "Cat"; // output: ""
const expr6 = "Cat" && ""; // output: ""

// // examples of logical OR operator
// const expr1 = true || true; // output: true
// const expr2 = true || false; // output: true
// const expr3 = false || true; // output: true
// const expr4 = "Dog" || "Cat"; // output: Dog
// const expr5 = "" || "Cat"; // output: Cat
// const expr6 = "Cat" || ""; // output: Cat

// // examples of logical NOT operator
// const expr1 = !true; // output: false
// const expr2 = !false; // output: true
// const expr3 = !"Cat"; // output: false
// const expr4 = !""; // output: true
