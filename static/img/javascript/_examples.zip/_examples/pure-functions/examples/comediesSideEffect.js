const comedies = ["The Office", "Friends"];

const appendShows = (shows, newShow) => {
  shows.push(newShow);
  return shows;
};

const newShows = appendShows(comedies, "Orange is the new black");
console.log(newShows);

console.log(comedies);
