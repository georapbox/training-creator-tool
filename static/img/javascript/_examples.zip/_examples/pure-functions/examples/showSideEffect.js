const show = {
  title: "Squid Game",
  episodes: 8,
  currentEpisode: 3,
};

const showNextEpisode = () => {
  show.currentEpisode = show.currentEpisode + 1;
  return show;
};

showNextEpisode();
console.log(show);

showNextEpisode();
console.log(show);
