// anonymous function expression
(function () {
  console.log("Hello, stranger!");
})(); // output: Hello, stranger!

// named function expression
(function sayHello() {
  console.log("Hello, stranger!");
})(); // output: Hello, stranger!

// cannot be invoked again
sayHello(); // ReferenceError: sayHello is not defined

// // we can store the return value in a variable
// const sayHello = (function () {
//   return "Hello, stranger!";
// })();

// // and use it as many times as we want
// console.log(sayHello); // output: Hello, stranger!
// console.log(sayHello); // output: Hello, stranger!
