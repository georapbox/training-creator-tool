// zero parameters
const sayHello = () => {
  return "Hello, stranger!";
};

// // one parameter
// const sayHello = name => {
//   return `Hello, ${name}!`;
// };

// // multiple parameters
// const sayHello = (name1, name2) => {
//   return `Hello, ${name1} and ${name2}!`;
// };

// // single line block
// const sayHello = () => "Hello, stranger!";
// const sayHello = name => `Hello, ${name}!`;

// // is equivalent to
// const sayHello = () => {
//   return "Hello, stranger!";
// };
// const sayHello = name => {
//   return `Hello, ${name}!`;
// };

console.log(sayHello());
