function sayHello(name = "stranger") {
  console.log(`Hello, ${name}!`);
}

sayHello(); // output: Hello, stranger!
sayHello("Sofia"); // output: Hello, Sofia!
