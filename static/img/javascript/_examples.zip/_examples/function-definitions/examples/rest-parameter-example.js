function sayHello(...name) {
  for (let i = 0; i < name.length; i++) {
    console.log(`Hello, ${name[i]}!`);
  }
}

sayHello("Sofia", "Kostis", "Afroditi");

/* output: 
  Hello, Sofia!
  Hello, Kostis!
  Hello, Afroditi!
  */
