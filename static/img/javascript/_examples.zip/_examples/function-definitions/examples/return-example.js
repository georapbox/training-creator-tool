function sayHello(name) {
  if (name !== "Sofia") {
    return "Hello, stranger!";
  }
  return `Hello, ${name}!`;
}

console.log(sayHello("Sofia")); // output: Hello, Sofia!
console.log(sayHello("Kostis")); // output: Hello, stranger!
