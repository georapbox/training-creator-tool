const sayHello = function (name) {
  return `Hello, ${name}!`;
};

console.log(sayHello("Sofia")); // output: Hello, Sofia!
