// function sayHello() has three parameters: name1, name2, name3
function sayHello(name1, name2, name3) {
  console.log(`Hello, ${name1}!`);
  console.log(`Hello, ${name2}!`);
  console.log(`Hello, ${name3}!`);
}

// function invocation receives three arguments: "Sofia", "Kostis", "Afroditi"
sayHello("Sofia", "Kostis", "Afroditi");

/* output: 
  Sofia
  Kostis
  Afroditi
  */
