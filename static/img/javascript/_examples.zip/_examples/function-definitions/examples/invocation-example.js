// function declaration
function sayHello() {
  console.log("Hello, stranger!");
}

// function invocation
sayHello(); // output: Hello, stranger!
