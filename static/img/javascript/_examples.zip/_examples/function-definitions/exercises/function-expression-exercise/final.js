// Solution:
const final = function (initialPrice, discountPercent) {
  return initialPrice - (initialPrice * discountPercent) / 100.0;
};

module.exports = final;
