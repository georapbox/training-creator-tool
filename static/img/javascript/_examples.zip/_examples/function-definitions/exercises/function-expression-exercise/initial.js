/*
Task:
    It's shopping time! 
    But we need an easy way to calculate discounts. 
    Write a function expression that takes the initial price and the discount percent
    and returns the final price.
*/

// TODO: provide implementation
