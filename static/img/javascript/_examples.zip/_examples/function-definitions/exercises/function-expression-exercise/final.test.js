const initial = require("./initial");

it("calls initial with two arguments, 170 as initialPrice and 25 as discountPercent, returns initial price 127.5", () => {
  // GIVEN
  const initialPrice = 170;
  const discountPercent = 25;

  // WHEN
  const result = initial(initialPrice, discountPercent);

  // THEN
  expect(result).toEqual(127.5);
});
