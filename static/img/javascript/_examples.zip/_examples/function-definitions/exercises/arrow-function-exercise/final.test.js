const initial = require("./initial");

it("calls final with one argument, 170 as initialPrice, returns final price 141.1", () => {
  // GIVEN
  const initialPrice = 170;

  // WHEN
  const result = initial(initialPrice);

  // THEN
  expect(result).toEqual(141.1);
});
