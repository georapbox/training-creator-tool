/*
Task:
    Refactor your discount calculator from the previous exercise, to use arrow function syntax
    as concise as possible.
    When there is no discount available, always calculate the initial price based on a 17% discount.
*/

// TODO: provide implementation
