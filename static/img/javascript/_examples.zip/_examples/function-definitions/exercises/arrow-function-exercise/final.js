// Solution:
const final = (initialPrice, discountPercent = 17) =>
  initialPrice - (initialPrice * discountPercent) / 100.0;

module.exports = final;
