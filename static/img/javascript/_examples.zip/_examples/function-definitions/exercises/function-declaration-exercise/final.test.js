const initial = require("./initial");

describe("declare winner", () => {
  it("should return 'We have a tie!' when myChoice is the same as yourChoice", () => {
    // GIVEN
    const myChoice = "rock";
    const yourChoice = "rock";

    // WHEN
    const result = initial(myChoice, yourChoice);

    // THEN
    expect(result).toEqual("We have a tie!");
  });

  it("should return 'Paper wins!' when myChoice is rock and yourChoice paper", () => {
    // GIVEN
    const myChoice = "rock";
    const yourChoice = "paper";

    // WHEN
    const result = initial(myChoice, yourChoice);

    // THEN
    expect(result).toEqual("Paper wins!");
  });

  it("should return 'Rock wins!' when myChoice is rock and yourChoice scissors", () => {
    // GIVEN
    const myChoice = "rock";
    const yourChoice = "scissors";

    // WHEN
    const result = initial(myChoice, yourChoice);

    // THEN
    expect(result).toEqual("Rock wins!");
  });

  it("should return 'Scissors win!' when myChoice is paper and yourChoice scissors", () => {
    // GIVEN
    const myChoice = "paper";
    const yourChoice = "scissors";

    // WHEN
    const result = initial(myChoice, yourChoice);

    // THEN
    expect(result).toEqual("Scissors win!");
  });

  it("should return 'Paper win!' when myChoice is paper and yourChoice rock", () => {
    // GIVEN
    const myChoice = "paper";
    const yourChoice = "rock";

    // WHEN
    const result = initial(myChoice, yourChoice);

    // THEN
    expect(result).toEqual("Paper wins!");
  });

  it("should return 'Rock wins!' when myChoice is scissors and yourChoice rock", () => {
    // GIVEN
    const myChoice = "scissors";
    const yourChoice = "rock";

    // WHEN
    const result = initial(myChoice, yourChoice);

    // THEN
    expect(result).toEqual("Rock wins!");
  });

  it("should return 'Scissors wins!' when myChoice is scissors and yourChoice paper", () => {
    // GIVEN
    const myChoice = "scissors";
    const yourChoice = "paper";

    // WHEN
    const result = initial(myChoice, yourChoice);

    // THEN
    expect(result).toEqual("Scissors win!");
  });
});
