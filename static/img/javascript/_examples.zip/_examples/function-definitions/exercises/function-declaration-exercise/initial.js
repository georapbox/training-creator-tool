/* 
Task:
    Let's play rock, paper, scissors!
    Write a function that takes as parameters our choices,
    compares them and determines the winner. 
    
    The possible outcomes are:
    1) rock vs paper, "Paper wins!"
    2) paper vs scissors, "Scissors win!"
    3) scissors vs rock, "Rock wins!"
    4) "We have a tie!"
*/

// TODO: provide implementation
