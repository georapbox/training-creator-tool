function final(myChoice, yourChoice) {
  if (myChoice === yourChoice) {
    return "We have a tie!";
  } 
  
  if (myChoice === "rock") {
    if (yourChoice === "paper") {
      return "Paper wins!";
    } else {
      return "Rock wins!";
    }
  } 
  
  if (myChoice === "paper") {
    if (yourChoice === "scissors") {
      return "Scissors win!";
    } else {
      return "Paper wins!";
    }
  } 
  
  if (myChoice === "scissors") {
    if (yourChoice === "rock") {
      return "Rock wins!";
    } else {
      return "Scissors win!";
    }
  }
}

module.exports = final;
