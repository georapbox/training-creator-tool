/* Task:
  Update a variable named grade whose value can be from 0-100.

  You should update the gradeResult with maching result of grade as below:
  - Grade of 90 and above means that gradeResult should be updated to A
  - Grade of 80 to 89 means that gradeResult should be updated to B
  - Grade of 70 to 79 means that gradeResult should be updated to C
  - Grade of 60 to 69 means that gradeResult should be updated to D
  - Grade of 59 or below means that gradeResult should be updated to F

  HINT: Use the if...else statement. 
*/

const initial = (grade) => {
  let gradeResult;

  // TODO: provide implementation

  return gradeResult;
};

module.exports = initial;
