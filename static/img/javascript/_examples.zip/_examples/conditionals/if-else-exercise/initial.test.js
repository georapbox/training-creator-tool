const initial = require("./initial");

describe("computes grade", () => {
  it("should return B when grade is 80", () => {
    // GIVEN
    let grade = 80;

    // WHEN
    const result = initial(grade);

    // THEN
    expect(result).toBe("B");
  });

  it("should return A when grade is 100", () => {
    // GIVEN
    let grade = 100;

    // WHEN
    const result = initial(grade);

    // THEN
    expect(result).toBe("A");
  });

  it("should return F when grade is 4", () => {
    // GIVEN
    let grade = 4;

    // WHEN
    const result = initial(grade);

    // THEN
    expect(result).toBe("F");
  });
});
