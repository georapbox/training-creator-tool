const final = (grade) => {
  let gradeResult;

  if (grade >= 90) {
    gradeResult = "A";
  } else if (grade >= 80) {
    gradeResult = "B";
  } else if (grade >= 70) {
    gradeResult = "C";
  } else if (grade >= 60) {
    gradeResult = "D";
  } else {
    gradeResult = "F";
  }

  return gradeResult;
};

module.exports = final;
