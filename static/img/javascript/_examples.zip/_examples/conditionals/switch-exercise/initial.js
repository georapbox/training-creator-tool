/* Task:
  Check a variable called day whose value represents a day of the week (1 - 7).

  Also, update a variable called dayName (inside each case) based on the value of the corresponding day.
  For example if day = 7, dayName should be updated to 'Sunday'.
  If the day has other than 1 - 7 as value, it should return "Invalid day". 

  HINT: Use the switch statement. 
 */

const initial = (day) => {
  let dayName;

  // TODO: provide implementation

  return dayName;
};

module.exports = initial;
