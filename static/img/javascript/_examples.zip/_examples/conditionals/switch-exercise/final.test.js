const initial = require("./initial");

describe("checks day number", () => {
  it("should return 'Friday' when day is 5", () => {
    // GIVEN
    let day = 5;

    // WHEN
    const result = initial(day);

    // THEN
    expect(result).toBe("Friday");
  });

  it("should return 'Monday' when day is 1", () => {
    // GIVEN
    let day = 1;

    // WHEN
    const result = initial(day);

    // THEN
    expect(result).toBe("Monday");
  });

  it("should return 'Invalid day' when day is bigger than 7 or smaller than 1", () => {
    // GIVEN
    let day = 12;

    // WHEN
    const result = initial(day);

    // THEN
    expect(result).toBe("Invalid day");
  });
});
