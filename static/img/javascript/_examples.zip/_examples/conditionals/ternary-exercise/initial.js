/* Task:
  Update a variable named isAuthenticated (boolean).
  If it is true update message variable to 'Enter', else to 'Leave'.
  
  HINT: Use the ternary operator.
 */

const initial = (isAuthenticated) => {
  let message;

  // TODO: provide implementation

  return message;
};

module.exports = initial;
