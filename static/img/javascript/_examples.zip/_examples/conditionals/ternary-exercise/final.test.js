const initial = require("./initial");

describe("decides based on if user is authenticated", () => {
  it("should return 'Leave' if user is not authenticated", () => {
    // GIVEN
    let isAuthenticated = false;

    // WHEN
    const result = initial(isAuthenticated);

    // THEN
    expect(result).toBe("Leave");
  });

  it("should return 'Enter' if user is authenticated", () => {
    // GIVEN
    let isAuthenticated = true;

    // WHEN
    const result = initial(isAuthenticated);

    // THEN
    expect(result).toBe("Enter");
  });
});
