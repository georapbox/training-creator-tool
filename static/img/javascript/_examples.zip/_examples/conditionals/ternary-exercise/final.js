const final = (isAuthenticated) => {
  let message;

  message = isAuthenticated ? "Enter" : "Leave";

  return message;
};

module.exports = final;
