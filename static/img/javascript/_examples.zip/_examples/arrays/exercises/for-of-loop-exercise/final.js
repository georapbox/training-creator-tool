//Solution:
const sofiasFollowers = ["Afroditi", "Thanos", "Kostis", "John", "Christine"];
const kostisFollowers = ["Thanos", "Helen", "Sofia", "Christine", "George"];

const final = (followersListA, FollowersListB) => {
  let mutualFollowers = [];
  for (const followerA of followersListA) {
    for (const followerB of FollowersListB) {
      if (followerA === followerB) {
        mutualFollowers.push(followerA);
      }
    }
  }
  return mutualFollowers;
};

module.exports = final;
