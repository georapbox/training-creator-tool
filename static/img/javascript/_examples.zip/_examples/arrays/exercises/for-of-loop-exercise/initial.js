/*
Task:
    Write a program that iterates over two lists of followers,
    pushes the mutual followers into a third list
    and returns the new list.
*/

const sofiasFollowers = ["Afroditi", "Thanos", "Kostis", "John", "Christine"];
const kostisFollowers = ["Thanos", "Helen", "Sofia", "Christine", "George"];

// TODO: provide implementation
