const initial = require("./initial");

describe("compares the items of two lists", () => {
  it("returns a new one with the common items", () => {
    // GIVEN
    const sofiasFollowers = [
      "Afroditi",
      "Thanos",
      "Kostis",
      "John",
      "Christine",
    ];
    const kostisFollowers = ["Thanos", "Helen", "Sofia", "Christine", "George"];

    // WHEN
    const result = initial(sofiasFollowers, kostisFollowers);

    // THEN
    expect(result).toEqual(["Thanos", "Christine"]);
  });
});
