const initial = require("./initial");

it("calls initial with an array of strings and returns a new array that contains the first character of each string", () => {
  // GIVEN
  const animals = ["hippopotamus", "elephant", "lion", "leopard", "okapi"];

  // WHEN
  const result = initial(animals);

  // THEN
  expect(result).toEqual(["h", "e", "l", "l", "o"]);
});
