/* 
Task:
    Let's decode a secret message!
    Given the list of animals below, 
    create a function that takes animals array 
    and returns a new array that contains the first character of each string element.
*/

const animals = ["hippopotamus", "elephant", "lion", "leopard", "okapi"];

// TODO: provide implementation
