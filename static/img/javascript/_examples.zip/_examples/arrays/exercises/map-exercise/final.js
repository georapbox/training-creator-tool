// Solution:
const animals = ["hippopotamus", "elephant", "lion", "leopard", "okapi"];

const final = (animals) => animals.map((animal) => animal[0]);

module.exports = final;
