// Solution:
const people = [
  { name: "Sofia", age: 28, id: true },
  { name: "Kostis", age: 35, id: true },
  { name: "Afroditi", age: 22, id: false },
  { name: "George", age: 30, id: false },
  { name: "John", age: 25, id: true },
  { name: "Christine", age: 16, id: true },
];

const final = (people) => people.filter(({ age, id }) => age >= 18 && !!id);

module.exports = final;
