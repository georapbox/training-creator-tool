const initial = require("./initial");

it("calls initial with a coffeeMenu array as argument and returns a new array with updated prices", () => {
  // GIVEN
  const coffeeMenu = [
    { coffee: "espresso", price: 2.5 },
    { coffee: "cappuccino", price: 3.5 },
    { coffee: "macchiato", price: 4 },
    { coffee: "americano", price: 3 },
    { coffee: "irish", price: 5.5 },
  ];

  // WHEN
  const result = initial(coffeeMenu);

  // THEN
  const newCoffeeMenu = [
    { coffee: "espresso", price: 3.5 },
    { coffee: "cappuccino", price: 4.5 },
    { coffee: "macchiato", price: 5 },
    { coffee: "americano", price: 4 },
    { coffee: "irish", price: 6.5 },
  ];

  expect(result).toEqual(newCoffeeMenu);
});
