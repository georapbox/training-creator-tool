/*
Task:
  Given the coffee menu below,
  create a function that iterates over the coffee options, 
  updates coffee prices by adding one
  and returns a new coffee menu.
  Be careful not to mutate the original.
*/

const coffeeMenu = [
  { coffee: "espresso", price: 2.5 },
  { coffee: "cappuccino", price: 3.5 },
  { coffee: "macchiato", price: 4 },
  { coffee: "americano", price: 3 },
  { coffee: "irish", price: 5.5 },
];

// TODO: provide implementation
