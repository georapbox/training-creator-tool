// Solution:
const coffeeMenu = [
  { coffee: "espresso", price: 2.5 },
  { coffee: "cappuccino", price: 3.5 },
  { coffee: "macchiato", price: 4 },
  { coffee: "americano", price: 3 },
  { coffee: "irish", price: 5.5 },
];

const final = (coffeeMenu) =>
  coffeeMenu.map((coffee) => {
    const price = coffee.price + 1;
    return { ...coffee, price };
  });

module.exports = final;
