/*
Task:
    We have to do some chores! 
    Create a program that will organize our lists of chores:
    A) You owe me a favor for being such a good tutor. You will do my chores too!
    Use a method to link my list of chores to yours. 
    B) Do not worry about the laundry, I have already taken care of it. 
    Use a method to remove the last element from chores. 
    C) We will have guests tonight!
    Use a method to add two elements to the chores array, "cook dinner" and "wash dishes".
*/

const yourChores = ["mop floor", "take out trash", "dust furnitures"];
const myChores = ["shop groceries", "fold clean clothes", "do laundry"];

// TODO: provide implementation
