const initial = require("./initial");

it("calls initial with two lists of chores and returns a new list", () => {
  // GIVEN
  const yourChores = ["mop floor", "take out trash", "dust furnitures"];
  const myChores = ["shop groceries", "fold clean clothes", "do laundry"];

  // WHEN
  const result = initial(yourChores, myChores);

  // THEN
  const newList = [
    "mop floor",
    "take out trash",
    "dust furnitures",
    "shop groceries",
    "fold clean clothes",
    "cook dinner",
    "wash dishes",
  ];

  expect(result).toEqual(newList);
});
