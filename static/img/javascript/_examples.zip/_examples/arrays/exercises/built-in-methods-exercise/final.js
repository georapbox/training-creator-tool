// Solution:
const yourChores = ["mop floor", "take out trash", "dust furnitures"];
const myChores = ["shop groceries", "fold clean clothes", "do laundry"];

const final = (yourChores, myChores) => {
  const newList = yourChores.concat(myChores);
  newList.pop();
  newList.push("cook dinner", "wash dishes");
  return newList;
};

module.exports = final;
