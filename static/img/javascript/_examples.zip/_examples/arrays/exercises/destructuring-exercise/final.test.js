const initial = require("./initial");

it("calls initial with a list of flowers and returns my favorite flower, peony", () => {
  // GIVEN
  const flowers = ["rose", "lily", "peony", "daffodil"];

  // WHEN
  const result = initial(flowers);

  // THEN
  expect(result).toBe("peony");
});
