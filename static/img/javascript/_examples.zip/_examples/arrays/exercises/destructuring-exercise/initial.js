/*
Task:
    Given the following list of flowers,
    Create a function that returns my favorite flower, peony.
    
*/

const flowers = ["rose", "lily", "peony", "daffodil"];

// TODO: provide implementation
