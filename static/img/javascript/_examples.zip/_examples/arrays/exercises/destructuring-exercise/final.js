// Solution:
const flowers = ["rose", "lily", "peony", "daffodil"];

const final = (flowers) => {
  const [, , favoriteFlower] = flowers;
  return favoriteFlower;
};

module.exports = final;
