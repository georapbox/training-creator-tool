const initial = require("./initial");

it("calls initial with an array of objects and returns a single object", () => {
  // GIVEN
  const professionals = [
    { firstName: "Natasha", lastName: "Romanoff", occupation: "spy" },
    {
      firstName: "Peter",
      lastName: "Parker",
      occupation: "freelance photographer",
    },
    {
      firstName: "Jessica",
      lastName: "Jones",
      occupation: "private investigator",
    },
    { firstName: "Bruce", lastName: "Banner", occupation: "scientist" },
    { firstName: "Carol", lastName: "Danvers", occupation: "air force pilot" },
    { firstName: "Stephen", lastName: "Strange", occupation: "doctor" },
  ];
  // WHEN
  const result = initial(professionals);

  // THEN
  const returnedObj = {
    "Natasha Romanoff": "spy",
    "Peter Parker": "freelance photographer",
    "Jessica Jones": "private investigator",
    "Bruce Banner": "scientist",
    "Carol Danvers": "air force pilot",
    "Stephen Strange": "doctor",
  };

  expect(result).toEqual(returnedObj);
});
