// Solution:
const professionals = [
  { firstName: "Natasha", lastName: "Romanoff", occupation: "spy" },
  {
    firstName: "Peter",
    lastName: "Parker",
    occupation: "freelance photographer",
  },
  {
    firstName: "Jessica",
    lastName: "Jones",
    occupation: "private investigator",
  },
  { firstName: "Bruce", lastName: "Banner", occupation: "scientist" },
  { firstName: "Carol", lastName: "Danvers", occupation: "air force pilot" },
  { firstName: "Stephen", lastName: "Strange", occupation: "doctor" },
];

const final = (professionals) =>
  professionals.reduce((professionalsObj, user) => {
    var fullName = `${user.firstName} ${user.lastName}`;
    professionalsObj[fullName] = user.occupation;
    return professionalsObj;
  }, {});

module.exports = final;
