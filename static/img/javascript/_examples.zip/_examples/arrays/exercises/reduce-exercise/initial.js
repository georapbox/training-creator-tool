/*
Task:
    Create a function that simplifies the structure of professionals array, 
    reducing it to a single object that uses professionals' full name as the key
    and their occupation as the value.
*/

const professionals = [
  { firstName: "Natasha", lastName: "Romanoff", occupation: "spy" },
  {
    firstName: "Peter",
    lastName: "Parker",
    occupation: "freelance photographer",
  },
  {
    firstName: "Jessica",
    lastName: "Jones",
    occupation: "private investigator",
  },
  { firstName: "Bruce", lastName: "Banner", occupation: "scientist" },
  { firstName: "Carol", lastName: "Danvers", occupation: "air force pilot" },
  { firstName: "Stephen", lastName: "Strange", occupation: "doctor" },
];
// TODO: provide implementation
