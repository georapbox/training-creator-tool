const favoriteWords = ["nostalgia", "petrichor", "euphoria"];

favoriteWords.forEach((word) => console.log(word));
