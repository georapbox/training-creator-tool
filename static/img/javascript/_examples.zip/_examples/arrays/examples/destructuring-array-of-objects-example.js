const numArr = [{ num1: 1 }, { num2: 2 }, { num3: 3 }];
const [{ num1 }, { num2 }, { num3 }] = numArr;

console.log(num1);
console.log(num2);
console.log(num3);
