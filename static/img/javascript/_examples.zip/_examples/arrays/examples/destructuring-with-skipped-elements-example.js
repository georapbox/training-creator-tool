const numArr = [1, 2, 3];
const [, , num3] = numArr;

console.log(num3);
