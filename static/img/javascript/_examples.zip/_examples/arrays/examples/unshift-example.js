const holidays = ["Easter", "Halloween", "Christmas"];

holidays.unshift("Hanykkah");

console.log(holidays);
