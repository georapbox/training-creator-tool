const shoppingList = ["bread", "milk", "eggs", "coffee"];

for (const item of shoppingList) {
  console.log(`- ${item}`);
}
