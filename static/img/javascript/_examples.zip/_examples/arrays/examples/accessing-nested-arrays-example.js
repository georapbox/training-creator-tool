const nestedArr = [[1], [1, 2]];

console.log(nestedArr[1]);
console.log(nestedArr[1][0]);
