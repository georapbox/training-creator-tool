const holidays = ["Easter", "Halloween", "Christmas"];

holidays.push("Hanukkah");

console.log(holidays);
