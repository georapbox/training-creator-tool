const numArr = [1, 2, 3, 4];

const newNumArr = numArr.map((number) => number * 10);

console.log(newNumArr); // output: [10, 20, 30, 40]
