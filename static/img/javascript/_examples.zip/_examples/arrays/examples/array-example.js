const stringArr = ["el1", "el2", "el3"];
const numArr = [1, 2, 3];
const boolArr = [true, true, false];
const nestedArr = [[1], [2, 3]];
const diverseArr = ["el1", 2, true, [4]];

console.log(stringArr.length);
