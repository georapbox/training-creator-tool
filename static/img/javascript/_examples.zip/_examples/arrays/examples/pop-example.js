const holidays = ["Easter", "Halloween", "Christmas"];

const removedHoliday = holidays.pop();

console.log(removedHoliday);
console.log(holidays);
