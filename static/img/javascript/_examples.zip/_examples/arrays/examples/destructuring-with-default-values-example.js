const numArr = [1, 2];
const [num1 = 11, num2 = 22, num3 = 33] = numArr;

console.log(num1);
console.log(num2);
console.log(num3);
