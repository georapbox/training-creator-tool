const numArr = [1, 6, 12, 15, 38, 23];

const odd = numArr.filter((number) => number % 2);

console.log(odd);
