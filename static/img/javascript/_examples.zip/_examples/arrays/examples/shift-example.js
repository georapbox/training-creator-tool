const holidays = ["Easter", "Halloween", "Christmas"];

const removedHoliday = holidays.shift();

console.log(removedHoliday);
console.log(holidays);
