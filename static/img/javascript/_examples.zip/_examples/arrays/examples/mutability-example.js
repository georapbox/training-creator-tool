const holidays = ["Easter", "Halloween", "Christmas"];

holidays[2] = "Hanukkah";

console.log(holidays);

holidays = "Saint Patrick's Day";
