const holidays = ["Easter", "Halloween", "Christmas"];

const halloweenIndex = holidays.indexOf("Halloween");
const hanukkahIndex = holidays.indexOf("Hanukkah");

console.log(halloweenIndex);
console.log(hanukkahIndex);
