const desserts = ["lemon pie", "tiramisu", "profiterole"];

desserts[2] = "ice cream";

console.log(desserts);
