const holidays = ["Easter", "Halloween", "Christmas"];
const moreHolidays = ["Hanukkah", "New Year's Day"];

const allHolidays = holidays.concat(moreHolidays);

console.log(holidays);
console.log(moreHolidays);
console.log(allHolidays);
