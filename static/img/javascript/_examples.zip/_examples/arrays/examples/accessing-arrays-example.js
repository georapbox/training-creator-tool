const desserts = ["lemon pie", "tiramisu", "profiterole"];

console.log(desserts[0]);
console.log(desserts[1]);
console.log(desserts[2]);
