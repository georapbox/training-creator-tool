const odd = [1, 3, 5];
const even = [2, 4, 6];

// using .concat() method
const combinedWithConcat = odd.concat(even);

// using spread operator instead of .concat()
const combinedWithSpread = [...odd, ...even];

console.log(combinedWithConcat);
console.log(combinedWithSpread);
