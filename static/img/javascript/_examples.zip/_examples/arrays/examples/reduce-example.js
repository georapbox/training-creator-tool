const numArr = [10, 20, 30];

// with initialValue
const sum = numArr.reduce((accumulator, current) => accumulator + current, 10);

console.log(sum);

// // without initialValue
// const sum = numArr.reduce((accumulator, current) => accumulator + current);

// console.log(sum);
