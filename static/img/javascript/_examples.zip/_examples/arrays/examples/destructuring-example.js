const numArr = [1, 2, 3];

const [num1, num2, num3] = numArr;

console.log(num1);
console.log(num2);
console.log(num3);
