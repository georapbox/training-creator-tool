sayHello();

const sayHello = () => {
  const greeting = "Hello";
  console.log(greeting);
};
