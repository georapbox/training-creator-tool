const sayHello = () => {
  console.log(greeting);
  let greeting = "Hello";
};

sayHello();
