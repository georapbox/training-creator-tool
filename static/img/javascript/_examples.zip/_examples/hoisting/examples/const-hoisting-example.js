const sayHello = () => {
  console.log(greeting);
  const greeting = "Hello";
};

sayHello();
