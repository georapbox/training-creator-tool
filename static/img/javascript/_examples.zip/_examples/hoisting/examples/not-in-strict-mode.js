console.log(hoist);
var hoist = "Hoisted";