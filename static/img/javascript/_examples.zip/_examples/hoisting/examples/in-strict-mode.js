"use strict";

console.log(hoist);
hoist = "Hoisted";