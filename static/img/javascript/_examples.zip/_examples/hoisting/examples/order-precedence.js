var num;

function num() {
  console.log('I am a function');
}

var num = 6;

console.log(typeof num);