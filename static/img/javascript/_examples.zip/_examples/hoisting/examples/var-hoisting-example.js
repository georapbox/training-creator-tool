const sayHello = () => {
  console.log(greeting);
  var greeting = "Hello";
  console.log(greeting);
};

sayHello();
