sayHello();

function sayHello() {
  const greeting = "Hello";
  console.log(greeting);
}
