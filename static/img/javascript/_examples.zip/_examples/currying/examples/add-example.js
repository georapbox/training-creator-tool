function add(a) {
  return function (b) {
    return function (c) {
      return a + b + c;
    };
  };
}

const arrowAdd = (a) => (b) => (c) => a + b + c;

const add1 = arrowAdd(1);
const add2 = add1(2);
const sum = add2(3);

console.log("Decalaration add:", add(1)(2)(3));
console.log("Arrow add:", sum);
