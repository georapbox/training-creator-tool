const salaryRaise = (raise) => (salary) => raise * salary;

const twelvePercentRaise = salaryRaise(0.12);

const bobRaise = twelvePercentRaise(2300);
const aliceRaise = twelvePercentRaise(1700);
const nickRaise = twelvePercentRaise(630);

console.log("Bob's raise:", bobRaise);
console.log("Alice's raise:", aliceRaise);
console.log("Nick's raise:", nickRaise);

const twentyPercentRaise = salaryRaise(0.2);

const superEmployeeRaise = twentyPercentRaise(2300);

console.log("Super employee's raise:", superEmployeeRaise);
