/* 
Task:
  Write a currying function called buildSandwich that each time is called, takes as a parameter a food ingredient.
  When called 3 times, it should return a string will all the ingredients.
  
  - Example: Returned value should be "Your sandwich has bacon, onions, tomatoes" when called with the following parameters.
    1) bacon
    2) onions
    3) tomatoes
*/

const buildSandwich = () => {
  // TODO: provide implementation
};

module.exports = buildSandwich;
