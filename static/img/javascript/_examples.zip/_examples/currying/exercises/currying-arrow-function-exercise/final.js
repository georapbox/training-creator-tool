const buildSandwich = (ingredient1) => (ingredient2) => (ingredient3) =>
  `Your sandwich has ${ingredient1}, ${ingredient2}, ${ingredient3}`;

module.exports = buildSandwich;
