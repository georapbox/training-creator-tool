const buildSandwich = require("./initial");

describe("buildSandwich", () => {
  it('should return "Your sandwich has bacon, onions, tomatoes", given the following arguments', () => {
    // GIVEN
    const ingredient1 = "bacon";
    const ingredient2 = "onions";
    const ingredient3 = "tomatoes";

    // WHEN
    const result = buildSandwich(ingredient1)(ingredient2)(ingredient3);

    // THEN
    expect(result).toEqual("Your sandwich has bacon, onions, tomatoes");
  });

  it('should return "Your sandwich has beef, avocado, bacon", when partially called', () => {
    // GIVEN
    const ingredient1 = "beef";
    const ingredient2 = "avocado";
    const ingredient3 = "bacon";

    // WHEN
    const sandwichWithBaseBeef = buildSandwich(ingredient1);
    const result = sandwichWithBaseBeef(ingredient2)(ingredient3);

    // THEN
    expect(result).toEqual("Your sandwich has beef, avocado, bacon");
  });
});
