/*
Task:
  Refactor your buildSandwitch function from the previous exercise, to use function declaration syntax.
*/

function buildSandwich() {
  // TODO: provide implementation
}

module.exports = buildSandwich;
