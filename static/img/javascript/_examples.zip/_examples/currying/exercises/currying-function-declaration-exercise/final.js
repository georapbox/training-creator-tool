function buildSandwich(ingredient1) {
  return function (ingredient2) {
    return function (ingredient3) {
      return `Your sandwich has ${ingredient1}, ${ingredient2}, ${ingredient3}`;
    };
  };
}

module.exports = buildSandwich;
