const newContext = ["this", "is", "the", "new", "context"];

function checkThis(firstName, lastName) {
  console.log(this === newContext);
  console.log(`Hello, ${firstName} ${lastName}!`);
}

checkThis.call(newContext, "Sofia", "Incredible");

checkThis.apply(newContext, ["Sofia", "Incredible"]);
