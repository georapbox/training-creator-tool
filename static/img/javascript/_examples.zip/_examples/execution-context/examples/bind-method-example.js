const newContext = ["this", "is", "the", "new", "context"];

function checkThis(firstName, lastName) {
  console.log(this === newContext);
  console.log(`Hello, ${firstName} ${lastName}!`);
}

const copyCheckThis = checkThis.bind(newContext, "Sofia", "Incredible");

copyCheckThis("Kostis", "Pine");
