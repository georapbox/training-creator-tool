class Context {
  constructor() {
    this.value = "the context is the objContext";
  }
  checkThis() {
    console.log(this === objContext);
  }
}

const objContext = new Context();

console.log(objContext.value);
objContext.checkThis(); 