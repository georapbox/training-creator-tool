function checkThis() {
  console.log(this === window);
}

checkThis();

function checkThisStrict() {
  "use strict";
  console.log(this === undefined);
}

checkThisStrict();
