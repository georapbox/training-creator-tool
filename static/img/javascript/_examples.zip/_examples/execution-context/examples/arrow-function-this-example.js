const objContext = {
  checkThis() {
    console.log(this === objContext);
    const innerFunc = () => console.log(this === objContext);
    innerFunc();
  },
};

objContext.checkThis();

////////////////////

// const objContext = {
//     value: "the context is NOT the objContext",
//     checkThis: () => {
//       console.log(this === window);
//       console.log(this.value);
//     },
//   };

//   objContext.checkThis();

////////////////////

// const checkThis = () => console.log(this === window);

// checkThis();

// const checkThisStrict = () => {
//   "use strict";
//   console.log(this === window);
// };

// checkThisStrict();

////////////////////

// const newContext = ["this", "is", "the", "new", "context"];

// function checkThis() {
//   console.log(this === newContext);
//   const innerFunc = () => console.log(this === newContext);
//   // try to change arrow function context
//   innerFunc.call(["this", "will", "not", "work"]);
//   innerFunc.apply(["nor", "this"]);
//   innerFunc.bind(["nor", "this"])();
// }

// checkThis.call(newContext);
