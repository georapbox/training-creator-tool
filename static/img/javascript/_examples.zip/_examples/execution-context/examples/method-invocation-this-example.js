const objContext = {
  checkThis() {
    console.log(this === objContext);
  },
};

objContext.checkThis();

////////////////////

// const objContext = {
//     value: "the context is the objContext",
//     checkThis() {
//       console.log(this === objContext);
//       console.log(this.value);
//     },
//   };

//   objContext.checkThis();

////////////////////

// const objContext = {
//     checkInnerThis() {
//       console.log(this === objContext);
//       function innerFunc() {
//         console.log(this === window);
//       }
//       innerFunc();
//     },
//   };

//   objContext.checkInnerThis();

////////////////////

// const objContext = {
//     checkThis() {
//       console.log(this === window);
//     },
//   };

//   const extractedMethod = objContext.checkThis;

//   extractedMethod();

////////////////////

// const objContext = {
//     checkThis() {
//       console.log(this === window);
//     },
//   };

//   setTimeout(objContext.checkThis, 1000);
