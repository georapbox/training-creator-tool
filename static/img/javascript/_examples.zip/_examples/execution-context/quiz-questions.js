// Can you find the result of using "this" in the following cases?

// A
const heroId = {
  name: "Diana",
  lastName: "Prince",
  alterEgo: "Wonder Woman",
  quote:
    "You are stronger than you believe. You have greater powers than you know.",
  getFullName() {
    console.log(`${this.alterEgo} is ${this.name} ${this.lastName}`);
  },
  getQuote: () => {
    console.log(`${this.alterEgo} says: ${this.quote}`);
  },
};

heroId.getFullName();
heroId.getQuote();

const getHeroName = heroId.getFullName;

getHeroName();

// B
class DroidFactory {
  constructor(model, name, quote) {
    this.model = model;
    this.name = name;
    this.quote = quote;
  }
  getDroidId() {
    console.log(`${this.name} is a ${this.model}`);
  }

  getDroidQuote = () => {
    console.log(`${this.name} says: ${this.quote}`);
  };
}

const threepio = new DroidFactory(
  "protocol droid",
  "C-3PO",
  "We seem to be made to suffer. It's our lot in life."
);

threepio.getDroidId();
threepio.getDroidQuote();

// C
const fantasticBeast = {
  species: "Hippogriff",
  name: "Buckbeak",
  owner: "Rubeus Hagrid",
  getOwner() {
    console.log(`The owner of ${this.name} is ${this.owner}.`);
  },
};

const getOwner = fantasticBeast.getOwner.bind(fantasticBeast);

setTimeout(getOwner, 1000);
