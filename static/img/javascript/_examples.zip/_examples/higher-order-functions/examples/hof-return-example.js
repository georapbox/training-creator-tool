// 1) With arrow function
const greetings = (name) => (greetingMessage) =>
  console.log(greetingMessage() + name);

// 1.a invocation with variable
const greetAlice = greetings("Alice");
const message = () => "Hello ";

greetAlice(message);

// 1.b invocation using double parentheses
// greetings("Bob")(message);
// greetings("Bob")(() => "Hello ");

// 2) With function declaration
// function greetings(name) {
//   return function (greetingMessage) {
//     console.log(greetingMessage() + name);
//   };
// }

// greetings("Bob")(function () {
//     return "Hello ";
// });
