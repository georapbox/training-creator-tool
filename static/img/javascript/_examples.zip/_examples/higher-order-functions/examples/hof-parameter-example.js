// With arrow function
const message = () => "Hi ";

const greetings = (greetingMessage, name) =>
  console.log(greetingMessage() + name);

// with function declaration
// function message() {
//   return "Hi ";
// }

// function greetings(greetingMessage, name) {
//   console.log(greetingMessage() + name);
// }

greetings(message, "Alice");
