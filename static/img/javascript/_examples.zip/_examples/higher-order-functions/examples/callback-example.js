const someCallbackFunc = () => console.log("I am a callback");

const print = (callback) => {
  console.log("I am calling the callback");

  callback();
};

print(someCallbackFunc);
