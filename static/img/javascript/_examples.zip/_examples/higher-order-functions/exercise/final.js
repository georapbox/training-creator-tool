const calculator = (number1, number2, operator) => operator(number1, number2);

const add = (number1, number2) => number1 + number2;
const multiply = (number1, number2) => number1 * number2;

module.exports = { calculator, add, multiply };
