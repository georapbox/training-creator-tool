/* Task:
  Create a calculator (higher order function) which takes the following parameters:
    a) number1
    b) number2
    c) operator (operator should be the callback function)

    
  It should return the result based on the operator. For example:
  - calculator(1, 2, add) // should return 3
  - calculator(3, 3, multiply) // should return 9

  Create only add and multiply operators.
*/

const calculator = () => {
  // TODO: provide implementation
};

const add = () => {
  // TODO: provide implementation
};

const multiply = () => {
  // TODO: provide implementation
};

module.exports = { calculator, add, multiply };
