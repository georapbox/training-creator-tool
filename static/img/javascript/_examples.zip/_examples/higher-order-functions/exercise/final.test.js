const { calculator, add, multiply } = require("./initial");

describe("calculator HOF", () => {
  it("should return 10 when called with 7, 3, add", () => {
    // GIVEN
    let number1 = 7;
    let number2 = 3;

    // WHEN
    const result = calculator(number1, number2, add);

    // THEN
    expect(result).toBe(10);
  });

  it("should return 24 when called with 6, 4, multiply", () => {
    // GIVEN
    let number1 = 6;
    let number2 = 4;

    // WHEN
    const result = calculator(number1, number2, multiply);

    // THEN
    expect(result).toBe(24);
  });
});
