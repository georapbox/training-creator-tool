function addNum() {
  const num1 = prompt('Enter num1: ');
  const num2 = prompt('Enter num2: ');

  if (num1 < 10) {
    const sum = +num1 + +num2;
    alert(`The sum of ${num1} and ${num2} is ${sum}`);
  } else {
    alert('Could not compute sum, sorry!');
  }
}
