let clicks = 0;

const increaseButton = document.getElementById("increment");
const decreaseButton = document.getElementById("decrement");
const result = document.querySelector("p");
result.innerHTML = clicks;

const handleIncrease = () => {
  clicks += 1;
  result.innerHTML = clicks;
};

const handleDecrease = () => {
  clicks -= 1;
  result.innerHTML = clicks;
};

increaseButton.addEventListener("click", handleIncrease);

decreaseButton.addEventListener("click", handleDecrease);
