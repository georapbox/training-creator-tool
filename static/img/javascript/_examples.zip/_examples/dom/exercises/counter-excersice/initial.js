/*
Task:
    We want to:
    1) Increase the counter (p element) by 1 when the user clicks on the Increase button.
    2) Descrease the counter by 1 when the user clicks on the Descrease button.
*/
