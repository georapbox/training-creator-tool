/*
Task:
    Find the bug and fix it.
    Expected behavior: Background color of a square should change ONLY if we click that same square.
    Present behavior: Clicking a square changes the color of all other elements.

    Tip: You should handle the event bubbling event :)
*/

const grandparent = document.querySelector("#grandparent");
const parent = document.querySelector("#parent");
const child = document.querySelector("#child");

grandparent.addEventListener("click", (event) => {
  console.log("grandparent");
  grandparent.style.backgroundColor = "lightgrey";
  // TODO: provide implementation
});

parent.addEventListener("click", (event) => {
  console.log("parent");
  parent.style.backgroundColor = "lightsalmon";
  // TODO: provide implementation
});

child.addEventListener("click", (event) => {
  console.log("child");
  child.style.backgroundColor = "yellow";
  // TODO: provide implementation
});
