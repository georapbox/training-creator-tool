const grandparent = document.querySelector("#grandparent");
const parent = document.querySelector("#parent");
const child = document.querySelector("#child");

grandparent.addEventListener("click", (event) => {
  console.log("grandparent");
  grandparent.style.backgroundColor = "lightgrey";
  event.stopPropagation();
});

parent.addEventListener("click", (event) => {
  console.log("parent");
  parent.style.backgroundColor = "lightsalmon";
  event.stopPropagation();
});

child.addEventListener("click", (event) => {
  console.log("child");
  child.style.backgroundColor = "yellow";
  event.stopPropagation();
});
