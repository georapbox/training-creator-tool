const handleCLick = () => console.log("Clicked");
const button = document.getElementById("button");

button.removeEventListener("click", handleCLick);