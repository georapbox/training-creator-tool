const header = document.querySelector("h1");
const hello = document.querySelector("#id1");
const world = document.querySelector(".class1");

header.innerHTML = "Updated Content";
header.style.color = "red";
header.style.backgroundColor = "blue";
