const input = document.getElementById("name");
const p = document.querySelector("p");

input.addEventListener("input", (event) => {
  console.log(event.target.value);
  p.innerHTML = event.target.value;
});
