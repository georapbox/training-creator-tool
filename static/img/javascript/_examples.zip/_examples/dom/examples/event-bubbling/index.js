const grandparent = document.querySelector("#grandparent");
const parent = document.querySelector("#parent");
const child = document.querySelector("#child");

document.addEventListener("click", (event) => {
  console.log("document");
});

grandparent.addEventListener("click", (event) => {
  console.log("grandparent");
});

parent.addEventListener("click", (event) => {
  console.log("parent");
});

child.addEventListener("click", (event) => {
  console.log("child");
});
