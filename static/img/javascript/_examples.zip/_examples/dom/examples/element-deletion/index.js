const secondDiv = document.querySelector("#id2");
secondDiv.remove();
