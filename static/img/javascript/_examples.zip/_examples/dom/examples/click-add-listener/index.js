const button = document.getElementById("button");

button.addEventListener("click", () => console.log("Clicked"));