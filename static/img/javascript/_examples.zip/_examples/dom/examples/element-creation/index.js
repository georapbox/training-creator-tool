const div = document.getElementById("id1");
const newElement = document.createElement("h1");
newElement.innerHTML = "World";
div.appendChild(newElement);
