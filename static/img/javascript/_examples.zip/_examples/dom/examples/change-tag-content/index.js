const header = document.querySelector("#id1");
header.innerHTML = "Updated content";