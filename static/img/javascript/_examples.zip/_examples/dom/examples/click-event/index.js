const button = document.getElementById("button");

button.addEventListener("click", (event) => {
    // the event listener callback receives the event object
    // through the event object, we have a reference to the object onto which the event was dispatched and specifically with the event.target
    console.log(event);
  });