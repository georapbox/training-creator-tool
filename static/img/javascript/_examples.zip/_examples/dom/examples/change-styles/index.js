const coloredRed = document.getElementById("id1");
coloredRed.style.color = "red";
coloredRed.style.backgroundColor = "blue";