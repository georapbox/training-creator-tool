// Can you find what will be logged to the console?

const promiseGenerator = (bool) => {
  return new Promise((resolve, reject) => {
    if (bool) {
      resolve("success");
    } else {
      reject("error");
    }
  });
};

const myPromise = promiseGenerator(true);

myPromise

  .then((resolvedVal) => {
    console.log(resolvedVal);
    return promiseGenerator(true);
  })

  .then((resolvedVal) => {
    if (resolvedVal !== "victory") {
      return promiseGenerator(false);
    }
    return promiseGenerator(true);
  })

  .then((resolvedVal) => {
    console.log(resolvedVal);
  })

  .catch((error) => {
    console.log(error);
    return promiseGenerator(false);
  })

  .then((resolvedVal) => {
    console.log(resolvedVal);
    return promiseGenerator(true);
  })

  .catch((error) => {
    console.log(error);
    return "Error caught";
  })

  .then((resolvedVal) => {
    console.log("Success:", resolvedVal);
  })

  .catch((resolvedVal) => {
    console.log("Error:", resolvedVal);
  });
