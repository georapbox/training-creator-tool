const myPromiseFunc = (num) =>
  new Promise((resolve, reject) => {
    setTimeout(() => {
      if (num < 20) {
        resolve(num * 2);
      } else {
        reject("I am rejected");
      }
    }, 1000);
  });

const myAsyncFunc = async (num) => {
  try {
    const firstResolvedVal = await myPromiseFunc(num);
    console.log(firstResolvedVal);

    const secondResolvedVal = await myPromiseFunc(firstResolvedVal);
    console.log(secondResolvedVal);

    const thirdResolvedVal = await myPromiseFunc(secondResolvedVal);
    console.log(thirdResolvedVal);
  } catch (error) {
    console.log(error);
  }
};

myAsyncFunc(5);
