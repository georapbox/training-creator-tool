const myPromiseFunc = () => {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve("I am resolved");
    }, 1000);
  });
};

async function myAsyncFunc() {
  const resolvedValue = await myPromiseFunc();
  console.log(resolvedValue);
}

myAsyncFunc();
