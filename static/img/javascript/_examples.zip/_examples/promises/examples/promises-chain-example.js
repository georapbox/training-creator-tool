const myPromiseFunc = (num) =>
  new Promise((resolve, reject) => {
    setTimeout(() => {
      if (num < 5) {
        resolve(num);
      } else {
        reject("I am rejected");
      }
    }, 1000);
  });

myPromiseFunc(2)
  .then((firstResolvedVal) => {
    return firstResolvedVal * 2;
  })
  .then((secondResolvedVal) => {
    console.log(secondResolvedVal);
  })
  .catch((error) => {
    console.log(error);
  });
