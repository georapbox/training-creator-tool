const executorFunction = (resolve, reject) => {
  setTimeout(() => {
    const num = Math.random();
    if (num < 0.5) {
      resolve("I am resolved");
    } else {
      reject("I am rejected");
    }
  }, 1000);
};

const myPromise = new Promise(executorFunction);

const handleSuccess = (resolvedValue) => console.log(resolvedValue);

const handleFailure = (error) => console.log(error);

myPromise.then(handleSuccess).catch(handleFailure);
