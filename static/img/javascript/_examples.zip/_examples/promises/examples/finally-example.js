myPromiseFunc(2)
  .then((firstResolvedVal) => {
    return firstResolvedVal * 2;
  })
  .then((secondResolvedVal) => {
    console.log(secondResolvedVal);
  })
  .catch((error) => {
    console.log(error);
  })
  .finally(() => console.log("I cleaned up"));
