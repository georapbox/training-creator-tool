// declare variable hero that holds an object
let hero = { name: "Batman" };

// declare variable copiedValue and assign it the value of variable a
let copiedValue = hero;

// both hero and copiedValue are now referencing the same object
console.log(hero.hero); // output: Batman
console.log(copiedValue.hero); // output: Batman

// modify value stored in hero property using variable copiedValue
copiedValue.hero = "Wonder Woman";

// change is also reflected in variable hero
console.log(hero.hero); // output: Wonder Woman
console.log(copiedValue.hero); // output: Wonder Woman
