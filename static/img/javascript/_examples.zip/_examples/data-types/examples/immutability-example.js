const arr = ["Hello", "world", "!"];
const str = "Hello world!";

// access array's first item and string's first character
console.log(arr[0]); // output: Hello
console.log(str[0]); // output: H

// change array's first item
arr[0] = "Goodbye";
console.log(arr); // output: ["Goodbye", "world", "!"]

// but cannot change string's first character
str[0] = "G";
console.log(str); // TypeError: Cannot assign to read only property '0' of string 'Hello world!'
