// declare variable greeting and initialize its value to "Hello"
let greeting = "Hello";

// declare variable copiedValue and assign it the value of variable greeting
let copiedValue = greeting;

console.log(greeting); // output: Hello
console.log(copiedValue); // output: Hello

// reassign variable copiedValue new value "Goodbye"
copiedValue = "Goodbye";

// value of variable greeting doesn't change
console.log(greeting); // output: Hello
console.log(copiedValue); // output: Goodbye
