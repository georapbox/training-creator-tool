console.log("Start");

setTimeout(() => {
  console.log("setTimeout");
});

Promise.resolve("promise").then((response) => console.log(response));

console.log("End");
