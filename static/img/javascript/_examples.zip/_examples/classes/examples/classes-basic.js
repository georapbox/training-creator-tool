class Person {
  constructor(firstName, birthYear) {
    this.firstName = firstName;
    this.birthYear = birthYear;
  }

  calculateAge() {
    console.log(2022 - this.birthYear);
  }
}

const alice = new Person("alice", 1991);

console.log(alice);
alice.calculateAge();
