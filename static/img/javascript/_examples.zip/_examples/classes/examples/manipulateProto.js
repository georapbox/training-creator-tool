Array.prototype.getFirstElement = function () {
  return this[0];
};

const arr = [3, 1, 4];
const getFirstElement = arr.getFirstElement();

console.log(getFirstElement);
