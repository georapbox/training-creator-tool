const Person = function (firstName, birthYear) {
  this.firstName = firstName;
  this.birthYear = birthYear;

  this.calculateAge = function () {
    console.log(2022 - this.birthYear);
  };
};

const alice = new Person("alice", 1991);
const bob = new Person("bob", 1989);

alice.calculateAge();

console.log("alice", alice);
console.log("bob", bob);
console.log("Is alice instance of Person ?", alice instanceof Person);
