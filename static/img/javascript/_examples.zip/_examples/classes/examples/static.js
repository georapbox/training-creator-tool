class Car {
  constructor(model) {
    this.model = model;
    Car.carsNumber += 1;
  }

  static carsNumber = 0;

  static startRace() {
    console.log("Race started");
  }
}

const car1 = new Car("Ford");
const car2 = new Car("Tesla");

console.log(Car.carsNumber);
console.log(car2.carsNumber);

Car.startRace();
car1.startRace();
