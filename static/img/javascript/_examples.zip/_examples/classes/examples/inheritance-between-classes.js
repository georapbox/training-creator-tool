class Car {
  constructor(doors, brand) {
    this.doors = doors;
    this.brand = brand;
  }

  printStats() {
    console.log(`${this.brand} has ${this.doors} doors`);
  }
}

class Supercar extends Car {
  constructor(doors, brand, cc) {
    super(doors, brand);
    this.cc = cc;
    this.status = "expensive";
  }

  printSupercarStats() {
    console.log(
      `${this.brand} has ${this.cc} cubic capacity and is ${this.status}`
    );
  }
}

const mercedes = new Supercar(4, "mercedes", 3000);
const ferrari = new Supercar(2, "ferrari", 4000);

console.log(mercedes);
console.log(ferrari);

ferrari.printStats();
mercedes.printSupercarStats();
