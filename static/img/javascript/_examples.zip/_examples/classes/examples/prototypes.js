const Person = function (firstName, birthYear) {
  this.firstName = firstName;
  this.birthYear = birthYear;
};

Person.prototype.calculateAge = function () {
  console.log(2022 - this.birthYear);
};

Person.prototype.planet = "earth";

const alice = new Person("alice", 1991);

console.log(alice);
console.log(alice.planet);
alice.calculateAge();

console.log(alice.hasOwnProperty("firstName"));
console.log(alice.hasOwnProperty("planet"));
