const Champion = require("./initial");

describe("Champio function constructor", () => {
  it("should create the expected object given the following parameters", () => {
    // GIVEN
    let name = "vayne";
    let attack = 95;
    let defense = 40;

    // WHEN
    const result = new Champion(name, attack, defense);

    // THEN
    expect(result).toEqual({
      name: "vayne",
      attack: 95,
      defense: 40,
    });
  });
});
