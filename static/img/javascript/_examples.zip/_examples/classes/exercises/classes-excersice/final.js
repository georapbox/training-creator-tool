class Champion {
  constructor(name, attack, defense) {
    this.name = name;
    this.attack = attack;
    this.defense = defense;
  }

  buffAttack() {
    this.attack = this.attack + 10;
    console.log(`New attack of ${this.name}`, this.attack);
  }

  defensePenetration() {
    this.defense = this.defense - 3;
    console.log(`New defense of ${this.name}`, this.defense);
  }
}

const vayne = new Champion("vayne", 95, 40);
const teemo = new Champion("teemo", 80, 55);

vayne.buffAttack();
vayne.buffAttack();
vayne.defensePenetration();

teemo.defensePenetration();
teemo.buffAttack();
teemo.defensePenetration();

module.exports = Champion;
