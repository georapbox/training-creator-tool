/*
Task:
    Use classes in order to make a Champion.
    A champion should have these properties:
        1) Name
        2) Attack (Number)
        3) Defense (Number)
    Also a champion should have acess to the following methods:
        1) buffAttack which should increase attack by 10 and log it to the console
        2) defensePenetration which should descrease defence by 3 and log it to the console

    Create 2 champion objects. Experiment by calling these methods multiple times.
*/

const Champion = function () {
  // TODO: provide implementation
};

module.exports = Champion;
