/*
Task:
   Continuing from classes excersice, our solution should look like below

    Now create a Mage subclass which should have these additional methods
        1) castSpell (should return "casted fireball")
        2) shieldAlly (should return "shielded an ally for ${givenAbilityPower} points")
        3) ultraCast (should log the two string above as follows. ${givenMageName} casted fireball and shielded an ally for ${givenAbilityPower} points)
*/

class Champion {
  constructor(name, attack, defense) {
    this.name = name;
    this.attack = attack;
    this.defense = defense;
  }

  buffAttack() {
    this.attack = this.attack + 10;
    console.log(`New attack of ${this.name}`, this.attack);
  }

  defensePenetration() {
    this.defense = this.defense - 3;
    console.log(`New defense of ${this.name}`, this.defense);
  }
}

class Mage extends Champion {
  // TODO: provide implementation
}

module.exports = Mage;
