class Champion {
  constructor(name, attack, defense) {
    this.name = name;
    this.attack = attack;
    this.defense = defense;
  }

  buffAttack() {
    this.attack = this.attack + 10;
    console.log(`New attack of ${this.name}`, this.attack);
  }

  defensePenetration() {
    this.defense = this.defense - 3;
    console.log(`New defense of ${this.name}`, this.defense);
  }
}

class Mage extends Champion {
  constructor(name, attack, defense, abilityPower) {
    super(name, attack, defense);
    this.abilityPower = abilityPower;
  }

  castSpell() {
    return `casted fireball`;
  }

  shieldAlly() {
    return `shielded an ally for ${this.abilityPower} points`;
  }

  ultraCast() {
    return `${this.name} ${this.castSpell()} and ${this.shieldAlly()}`;
  }
}

module.exports = Mage;
