const Mage = require("./initial");

describe("Mage class", () => {
  it("should return 'shielded an ally for 88 points given the following arguments' ", () => {
    // GIVEN
    let name = "lux";
    let attack = 20;
    let defense = 40;
    let abilityPower = 88;

    // WHEN
    const instance = new Mage(name, attack, defense, abilityPower);
    const result = instance.shieldAlly();

    // THEN
    expect(result).toBe("shielded an ally for 88 points");
  });

  it("Should return the expected result given the following arguments ", () => {
    // GIVEN
    let name = "lux";
    let attack = 20;
    let defense = 40;
    let abilityPower = 100;

    // WHEN
    const instance = new Mage(name, attack, defense, abilityPower);
    const result = instance.ultraCast();

    // THEN
    expect(result).toBe(
      "lux casted fireball and shielded an ally for 100 points"
    );
  });
});
