const hasProperties = require("./initial");

describe("hasProperties", () => {
  it("should return true, given the following arguments", () => {
    // GIVEN
    const obj = { a: 1, b: 2, c: 3 };

    // WHEN
    const result = hasProperties(obj, "a", "c");

    // THEN
    expect(result).toBe(true);
  });

  it("should return false, given the following arguments", () => {
    // GIVEN
    const obj = { a: 1, b: 2, c: 3 };

    // WHEN
    const result = hasProperties(obj, "a", "d");

    // THEN
    expect(result).toBe(false);
  });
});
