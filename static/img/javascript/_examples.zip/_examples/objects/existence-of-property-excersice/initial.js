/*
Task:
  Create a function that accepts an object as first argument, and then string values - their number is not defined.
  Return true if all the string arguments are keys of the object, otherwise return false.

  Example 1: 
  input: {a:10, b:0, c:30}, "c", "b",
  output: true

  Example 2: 
  input: {a:10, b:0, c:30}, "c", "a", "g",
  output: false

  Hint: Use the for..of statement to iterate on the keys. For more info, follow this link: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Statements/for...of
*/

const hasProperties = (obj, ...keys) => {
  // TODO: provide implementation
};

module.exports = hasProperties;
