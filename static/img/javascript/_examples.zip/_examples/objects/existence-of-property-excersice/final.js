const hasProperties = (obj, ...keys) => {
  for (const key of keys) {
    if (!obj.hasOwnProperty(key)) {
      return false;
    }
  }

  return true;
};

module.exports = hasProperties;
