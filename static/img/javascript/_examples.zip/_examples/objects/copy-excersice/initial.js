/*
Task:
  Create a function that accepts 2 objects and returns these 2 objects merged into a single one.
  You can use any of the 3 methods we learned for copying objects.

  input: {firstname: "Alice"}, { lastname: 'Bob' }
  output: {
    firstname: "Alice",
    lastname: 'Bob'
  }
*/

const mergeObjects = (obj1, obj2) => {
  // TODO: provide implementation
};

module.exports = mergeObjects;
