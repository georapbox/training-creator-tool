const mergeObjects = (obj1, obj2) => ({ ...obj1, ...obj2 });

// const mergeObjects = (obj1, obj2) => Object.assign(obj1, obj2);

module.exports = mergeObjects;
