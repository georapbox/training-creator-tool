const mergeObjects = require("./initial");

describe("mergeObjects", () => {
  it("should return the expected result, given the following argument", () => {
    // GIVEN
    const obj1 = {
      tv: 10,
      phone: 20,
    };

    const obj2 = {
      car: 32000,
    };

    // WHEN
    const result = mergeObjects(obj1, obj2);

    // THEN
    expect(result).toEqual({ tv: 10, phone: 20, car: 32000 });
  });

  it("should return the expected result, given empty second object", () => {
    // GIVEN
    const obj1 = {
      tv: 10,
      phone: 20,
    };

    const obj2 = {};

    // WHEN
    const result = mergeObjects(obj1, obj2);

    // THEN
    expect(result).toEqual({ tv: 10, phone: 20 });
  });
});
