const person1 = {
  name: "Afroditi",
  familyMembers: {
    son: "Kostis",
    daughter: "Sofia",
  },
};

const person2 = {
  ...person1,
  familyMembers: {
    ...person1.familyMembers,
  },
};

person2.name = "Alice";
person2.familyMembers.son = "Bob";

console.log(person1);
console.log(person2);
