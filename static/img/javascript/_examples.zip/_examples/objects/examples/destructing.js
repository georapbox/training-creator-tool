const car = {
  model: "tesla",
  price: 32000,
  used: true,
  damages: {
    engine: "oil change",
  },
};

// simple destructuring
const { model, price, used } = car;
const { used: isUsed } = car;

// default destructring
const { miles = 10000 } = car;

// nested destructuring
const {
  damages: { engine },
} = car;

console.log("model", model);
console.log("price", price);
console.log("used", used);
console.log("miles", miles);
console.log("isUsed", isUsed);
console.log("engine", engine);
