const person = {
  firstname: "Alice",
  lastname: "Bob",
  age: 36,
};

for (let key in person) {
  console.log(key);
}

console.log("keys", Object.keys(person));

console.log("values", Object.values(person));

console.log("entries", Object.entries(person));
