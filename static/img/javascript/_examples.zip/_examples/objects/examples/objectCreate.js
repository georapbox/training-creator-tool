const organization = { company: "Agile Actors" };

const employee = Object.create(organization, {
  name: { value: "Kostis" },
});

console.log("organization", organization);
console.log("employee", employee);

// Hint, we will talk about inheritance later on.
console.log("employee company", employee.company);
