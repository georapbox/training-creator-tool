const person1 = {
  name: "Afroditi",
  familyMembers: {
    son: "Kostis",
    daughter: "Sofia",
  },
};

const person2 = {
  ...person1,
};

person2.name = "Alice";
person2.familyMembers.son = "Bob";

console.log("person1", person1);
console.log("person2", person2);
