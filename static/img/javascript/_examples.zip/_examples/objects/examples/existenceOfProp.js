const user = {
  name: "Alice",
  age: 30,
};

console.log("in", "name" in user);
console.log("in", "job" in user);

console.log("hasOwnProperty", user.hasOwnProperty("name"));
console.log("hasOwnProperty", user.hasOwnProperty("job"));
