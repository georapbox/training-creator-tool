const user = {
  name: "Mayank Gupta",
  age: 30,
};

const newUser = Object.assign({}, user);
console.log("newUser", newUser);

newUser.gender = "male";

console.log("user", user);
console.log("newUser", newUser);
