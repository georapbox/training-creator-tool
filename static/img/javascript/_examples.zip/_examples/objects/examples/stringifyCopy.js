const user = {
  name: "Mayank",
  age: 22,
  greet: () => console.log("Hello"),
};

const stringifiedOutput = JSON.stringify(user);

const clonedObject = JSON.parse(stringifiedOutput);

console.log("clonedObject", clonedObject);
