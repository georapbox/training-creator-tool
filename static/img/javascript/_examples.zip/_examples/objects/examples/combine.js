const circle = { radius: 40 };
const styles = { borderColor: "yellow", background: "red" };
const styledCircle = { ...circle, ...styles };
console.log(styledCircle);
