const circle = { radius: 40 };
const redCircle = { ...circle, color: "red" };
console.log(redCircle);
